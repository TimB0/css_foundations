The 2013 CSSOff is LIVE!

You've been patient, you've been studying, you've been ready and now it's time.

Go and get the 2013 CSSOff design and begin the battle: http://ums.sc/cssoff/

Good luck to you all...

Make sure you've read all the rules and scoring breakdown as well as the terms here: http://ums.sc/cssoff/ 

When you think you're ready you can submit your entry here: http://cssoff.unmatchedstyle.com/entries/submit

----------------------------------------------------------------------

Notes for your entry files:

You must use http://codepen.io to deliver your entry.

First, if you don't already have a Codepen account signup for a free account here: https://codepen.io/signup/ 

Once you have your account, go here: http://codepen.io/promo/css-off-2013 and convert your account to a free CSSOff Pro level account for the duration of the contest. This will allow you to upload resources like images and javascript files and stuff.

Notes on the Codepen account:
- PRO accounts are provided free and with full access rights to privacy, asset hosting, collaboration, etc.
- The accounts are time limited from signup date to the end date of the CSOff contest.
- Users will not lose the work once the promotion ends.
- Private pens will stay that way unless the user chooses to publish them, but new private pens can’t be created.
- Assets uploaded during the promotion will stay uploaded, but once the promotion ends, new assets can’t be uploaded.

Have questions or need help? Email us: info@unmatchedstyle.com

----------------------------------------------------------------------

The Design:

The 2013 CSSOff contest design has been created by Sensei Dan Mall (https://twitter.com/danielmall) this year's design is not unlike last year's where you will be tested beyond your limits. It should be a challenge like last year's design from Paravel.

All the fonts used in the design are free Google Fonts: 

Oswald: http://www.google.com/fonts/specimen/Oswald
Lato: http://www.google.com/fonts/specimen/Lato
Merriweather: http://www.google.com/fonts/specimen/Merriweather
Lora: http://www.google.com/fonts/specimen/Lora

Good Luck & Don't Give Up!

Get full details and updates about CSSOff at http://unmatchedstyle.com/cssoff/. If you haven't already signed up to be notified by email, get on the list now grasshopper so you can keep up with all the CSSOff contest updates.